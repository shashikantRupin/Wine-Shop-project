const foo = ()=>{
    return `<div id="footer">
    <div>
        <div>
            <p><span>CATALOG</span></p>
            <p>Red Vine</p>
            <p>White Vine</p>
            <p>Rose Vine</p>
            <p>Sparkling Vines</p>
            <p>Promotions</p>
            <p>Sets And Gifts</p>
        </div>
        <div>
            <p><span>SUPPORT</span></p>
            <p>FAQ</p>
            <p>Terms Of use</p>
            <p>Delivery And Payment</p>
            <p>Return & Exchange</p>
        </div>
        <div>
            <p><span>OUR COMPANY</span></p>
            <p>About Us</p>
            <p>Contact Us</p>
            <p>Reviews</p>
            <p>Blog And News</p>
            <p>Loyalty Program</p>
            <p>Vine Subscription</p>
        </div>
        <div>
            <p><span>CONTACTS</span></p>
            <p>0 800 123 456</p>
            <p>info@minewine.com</p>
            <p><span>ADDRESS :</span></p>
            <p>Ukrain</p>
            <p>Kyiv,Bazhana St. 17</p>
            <p><span>WORKING HOURS : </span></p>
            <p>Mon-Fri 09:00-20:00</p>
            <p>Sat-Sun 10:00-18:00</p>
        </div>
    </div>
    <div>
        <div>
            <p>Mine Vine</p>
        </div>
        <div>
            <p>We Only Sell Alcohol To Adults 21+</p>
            <p>@MineVine 2023. All Rights Reserved</p>
        </div>
    </div>
</div>`
}
export default foo;