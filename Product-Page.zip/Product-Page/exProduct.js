import Navbar from './component/nav.js'
import foo from './component/footer.js'

document.getElementById("navbar").innerHTML = Navbar()
document.getElementById("footer").innerHTML = foo()


